# Practica 1 - Argumentos del main, estructuras, uniones, enumerados y typedef

- esta es la primera practica evaluable (del bloque de practicas obligatorias) que cuentan un 40% de la nota final. 
Habra 3 practicas obligatorias pertenecientes a dicho bloque. 
- En el documento adjunto teneis el enunciado de la primera practica y los detalles de lo que teneis que hacer. 
- Una vez realizada la entrega, se procedera a la realizacion de la tarea asociada a este ejercicio evaluable. Esta tarea consistira en la realizacion de un programa (o varios) inspirado en uno de los realizados en el ejercicio evaluable.
- La calificacion del ejercicio evaluable saldra de esta tarea y la entrega de los programas sera imprescindible para su calificacion.
- La calificacion de este ejercicio evaluable sera un tercio del 40%

## Consideraciones y Formato de la entrega: 

- El alumno realizara la practica de forma individual. Cualquier indicio de copia supondra el suspenso directo de la practica y repercutir directamente en el aprobado de la asignatura.
- Para la realizacion de los programas se puede utilizar cualquier editor, tipo NotePad++. Aplicar los conocimientos adquiridos en los temas 1 y 2 del temario
- Los archivos generados deben incluirse en un fichero .zip que es el que el alumno debe entregar y subir a BB y que debera estar nombrado de la siguiente manera:

NombreAlumno_Apellidos_Practica1_IPR1.zip

- La entrega debe realizarse en BB antes del 4/03/2025 a las 23:59 No se admitiran entregas que no sigan el formato descrito anteriormente o que se realicen despues de la fecha indicada. Si no se realiza la entrega el ejercicio se considerara suspenso con una calificacion de 0
 
Cualquier duda que tengais podremos resolverla los dias de clase de la semana que viene.